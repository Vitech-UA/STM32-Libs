/*
 * Fina_st7789.h
 *
 *  Created on: 11 мая 2020 г.
 *      Author: viktor.starovit
 */

#ifndef INC_FINA_ST7789_H_
#define INC_FINA_ST7789_H_

#include "stm32f7xx_hal.h"
#include "font7x11.h"
#define RGB565(r, g, b)  (((r & 0xF8) << 8) | ((g & 0xFC) << 3) | ((b & 0xF8) >> 3))




//#define SPI_LCD_PORT 1

#define DC_Pin GPIO_PIN_4
#define DC_GPIO_Port GPIOC

#define RES_Pin GPIO_PIN_4
#define RES_GPIO_Port GPIOA

#define ST7789_ColorMode_65K    0x50
#define ST7789_ColorMode_262K   0x60
#define ST7789_ColorMode_12bit  0x03
#define ST7789_ColorMode_16bit  0x05
#define ST7789_ColorMode_18bit  0x06
#define ST7789_ColorMode_16M    0x07

#define ST7789_Cmd_SWRESET      0x01
#define ST7789_Cmd_SLPIN        0x10
#define ST7789_Cmd_SLPOUT       0x11
#define ST7789_Cmd_COLMOD       0x3A
#define ST7789_Cmd_PTLON        0x12
#define ST7789_Cmd_NORON        0x13
#define ST7789_Cmd_INVOFF       0x20
#define ST7789_Cmd_INVON        0x21
#define ST7789_Cmd_GAMSET       0x26
#define ST7789_Cmd_DISPOFF      0x28
#define ST7789_Cmd_DISPON       0x29
#define ST7789_Cmd_CASET        0x2A
#define ST7789_Cmd_RASET        0x2B
#define ST7789_Cmd_RAMWR        0x2C
#define ST7789_Cmd_PTLAR        0x30
#define ST7789_Cmd_MADCTL       0x36
#define ST7789_Cmd_MADCTL_MY    0x80
#define ST7789_Cmd_MADCTL_MX    0x40
#define ST7789_Cmd_MADCTL_MV    0x20
#define ST7789_Cmd_MADCTL_ML    0x10
#define ST7789_Cmd_MADCTL_RGB   0x00
#define ST7789_Cmd_RDID1        0xDA
#define ST7789_Cmd_RDID2        0xDB
#define ST7789_Cmd_RDID3        0xDC
#define ST7789_Cmd_RDID4        0xDD
#define ST7789_MADCTL_MY        0x80
#define ST7789_MADCTL_MX        0x40
#define ST7789_MADCTL_MV        0x20
#define ST7789_MADCTL_ML        0x10
#define ST7789_MADCTL_BGR       0x08
#define ST7789_MADCTL_MH        0x04

#define BLACK    0x000000
#define BLUE     0x3739FF
#define RED      0x9D2400
#define GREEN    0x348934
#define CYAN     0x8fF9FF
#define MAGENTA  0xFF09FF
#define YELLOW   0xDEFF19
#define WHITE    0xFCFCFC


#define ST7789_X_Start          0
#define ST7789_Y_Start          0


/** Розділ прототипів **/
void vFinaLCD_Init();

void vFinaLCD_RamWrite(uint32_t *pBuff, uint16_t Len);
void vFinaLCD_SetWindow(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) ;

void vFinaLCD_SendCmd(uint8_t Cmd);
void vFinaLCD_SendData(uint8_t Data);

void vFinaLCD_HardReset(void);
void vFinaLCD_SoftReset(void);

void vFinaLCD_SleepModeEnter(void);
void vFinaLCD_SleepModeExit(void);

void vFinaLCD_ColumnSet(uint16_t ColumnStart, uint16_t ColumnEnd);
void vFinaLCD_RowSet(uint16_t RowStart, uint16_t RowEnd);
void vFinaLCD_ColorModeSet(uint8_t ColorMode);
void vFinaLCD_MemAccessModeSet(uint8_t Rotation, uint8_t VertMirror,uint8_t HorizMirror, uint8_t IsBGR);

/* Функції рисування */
void vFinaLCD_FillScreen(uint32_t color);
void vFinaLCD_FillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint32_t color);
void vFinaLCD_DrawPixel(int16_t x, int16_t y, uint32_t color);

void vFinaLCD_DrawBMP(uint16_t x, uint16_t y, const uint8_t *pArr);
void vFinaLCD_DisplayPower(uint8_t On);
void vFinaLCD_InversionMode(uint8_t Mode);
void vFinaLCD_DrawBitmapArray(const uint32_t *pData);

/* Відрисовка bitmap */
void vFinaLCD_WriteMultiple(uint8_t *pData, uint32_t size);
uint16_t alphaBlend(uint8_t alpha, uint16_t fgc, uint16_t bgc);
uint32_t vFinaLCD_Color565(uint8_t r, uint8_t g, uint8_t b);
uint32_t vFinaLCD_Color666(uint8_t r, uint8_t g, uint8_t b);

/*функції alphablend*/
uint32_t color16to24(uint16_t color565);
uint32_t alphaBlend24(uint8_t alpha, uint32_t fgc, uint32_t bgc, uint8_t dither);
uint16_t alphaBlendwD(uint8_t alpha, uint16_t fgc, uint16_t bgc, uint8_t dither);

/*Текст*/
void vFinaLCD_print_7x11(uint16_t x, uint16_t y, uint16_t TextColor, uint16_t BgColor, uint8_t TransparentBg, char *str);

#endif /* INC_FINA_ST7789_H_ */
