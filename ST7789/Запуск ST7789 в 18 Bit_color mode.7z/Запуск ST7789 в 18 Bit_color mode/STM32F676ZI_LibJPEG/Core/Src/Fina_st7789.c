/*
 * Fina_st7789.c
 *
 *  Created on: 11 мая 2020 г.
 *      Author: viktor.starovit
 */

#include "Fina_st7789.h"

#if SPI_LCD_PORT == 1
extern SPI_HandleTypeDef hspi1;
#define SPI_LCD_PORT SPI1
#endif

#if SPI_LCD_PORT == 2
extern SPI_HandleTypeDef hspi2;
#endif

#if(SPI_LCD_PORT == 3)

#endif

#if(SPI_LCD_PORT == 4)

#endif

extern SPI_HandleTypeDef hspi1;

uint8_t ST7789_Width, ST7789_Height;

void vFinaLCD_Init() {
	ST7789_Width = 240;
	ST7789_Height = 240;

	vFinaLCD_HardReset();
	vFinaLCD_SoftReset();
	vFinaLCD_SleepModeExit();
	vFinaLCD_ColorModeSet(ST7789_ColorMode_18bit);
	HAL_Delay(10);
	vFinaLCD_MemAccessModeSet(4, 1, 0, 0);
	HAL_Delay(10);
	vFinaLCD_InversionMode(1);
	HAL_Delay(10);
	vFinaLCD_FillScreen(BLACK);
	vFinaLCD_DisplayPower(1);
	HAL_Delay(100);
}

void vFinaLCD_RamWrite(uint32_t *pBuff, uint16_t Len) {
	/*
	 uint8_t R_COMPONENT = 0;
	 uint8_t G_COMPONENT = 0;
	 uint8_t B_COMPONENT = 0;

	 while (Len--) {

	 uint32_t RGB_COLOR = *pBuff;

	 R_COMPONENT = (RGB_COLOR << 10) & 0xFC; // LSB

	 G_COMPONENT = (RGB_COLOR << 4) & 0xFC;

	 B_COMPONENT = (RGB_COLOR >> 2) & 0xFC; // MSB

	 vFinaLCD_SendData(R_COMPONENT); // Запис 1 байту
	 vFinaLCD_SendData(G_COMPONENT); // Запис 2 байту
	 vFinaLCD_SendData(B_COMPONENT); // Запис 3 байту
	 }
	 */

	while (Len--) {
		vFinaLCD_SendData(*pBuff >> 16);
		vFinaLCD_SendData(*pBuff >> 8);
		vFinaLCD_SendData(*pBuff & 0xFF);
	}

}

void vFinaLCD_SendData(uint8_t Data) {
	HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET); /* Пін DC вгору для відправки даних */
	/* Прямий доступ до регістра даних SPI */
*((__IO uint8_t *) &SPI1->DR) = Data;
}

void vFinaLCD_SendCmd(uint8_t Cmd) {
HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_RESET); /* Пін DC вниз для відправки команд */

/* Відправка однобайтової команди */
/* Прямий доступ до SPI для для оптимізації */

HAL_SPI_Transmit(&hspi1, &Cmd, 1, 100);

}

void vFinaLCD_HardReset(void) {
HAL_GPIO_WritePin(RES_GPIO_Port, RES_Pin, GPIO_PIN_RESET);
HAL_Delay(10);
HAL_GPIO_WritePin(RES_GPIO_Port, RES_Pin, GPIO_PIN_SET);
HAL_Delay(150);
}

void vFinaLCD_SoftReset(void) {
vFinaLCD_SendCmd(ST7789_Cmd_SWRESET);
HAL_Delay(130);
}

void vFinaLCD_SleepModeEnter(void) {
vFinaLCD_SendCmd(ST7789_Cmd_SLPIN);
HAL_Delay(500);
}

void vFinaLCD_SleepModeExit(void) {
vFinaLCD_SendCmd(ST7789_Cmd_SLPOUT);
HAL_Delay(500);
}

void vFinaLCD_ColorModeSet(uint8_t ColorMode) {
vFinaLCD_SendCmd(ST7789_Cmd_COLMOD);
vFinaLCD_SendData(ColorMode & 0x77);
}

void vFinaLCD_SetWindow(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) {
vFinaLCD_ColumnSet(x0, x1);
vFinaLCD_RowSet(y0, y1);
vFinaLCD_SendCmd(ST7789_Cmd_RAMWR);
}

/*
 * Функція встановлення адреси стовпчика.
 * Ця команда використовується для визначеної області фреймової пам'яті,
 * до якої MCU може отримати доступ
 */
void vFinaLCD_ColumnSet(uint16_t ColumnStart, uint16_t ColumnEnd) {
if (ColumnStart > ColumnEnd)
	return;
if (ColumnEnd > ST7789_Width)
	return;

ColumnStart += ST7789_X_Start;
ColumnEnd += ST7789_X_Start;

vFinaLCD_SendCmd(ST7789_Cmd_CASET);
vFinaLCD_SendData(ColumnStart >> 8);
vFinaLCD_SendData(ColumnStart & 0xFF);
vFinaLCD_SendData(ColumnEnd >> 8);
vFinaLCD_SendData(ColumnEnd & 0xFF);
}

/*
 * Функція встановлення адреси строки.
 * Ця команда використовується для визначеної області фреймової пам'яті,
 * до якої MCU може отримати доступ
 */
void vFinaLCD_RowSet(uint16_t RowStart, uint16_t RowEnd) {
if (RowStart > RowEnd)
	return;
if (RowEnd > ST7789_Height)
	return;

RowStart += ST7789_Y_Start;
RowEnd += ST7789_Y_Start;

vFinaLCD_SendCmd(ST7789_Cmd_RASET);
/*Чотири параметри*/
vFinaLCD_SendData(RowStart >> 8);
vFinaLCD_SendData(RowStart & 0xFF);
vFinaLCD_SendData(RowEnd >> 8);
vFinaLCD_SendData(RowEnd & 0xFF);
}

void vFinaLCD_FillScreen(uint32_t color) {
vFinaLCD_FillRect(0, 0, ST7789_Width, ST7789_Height, color);
}

void vFinaLCD_FillRect(int16_t x, int16_t y, int16_t w, int16_t h,
	uint32_t color) {
if ((x >= ST7789_Width) || (y >= ST7789_Height))
	return;
if ((x + w) > ST7789_Width)
	w = ST7789_Width - x;
if ((y + h) > ST7789_Height)
	h = ST7789_Height - y;
vFinaLCD_SetWindow(x, y, x + w - 1, y + h - 1);
for (uint32_t i = 0; i < (h * w); i++)
	vFinaLCD_RamWrite(&color, 3);
}

/*
 * Функція з налаштуваннями режимів доступу до пам'яті
 */
void vFinaLCD_MemAccessModeSet(uint8_t Rotation, uint8_t VertMirror,
	uint8_t HorizMirror, uint8_t IsBGR) {
uint8_t Value;
Rotation &= 7;

vFinaLCD_SendCmd(ST7789_Cmd_MADCTL);

switch (Rotation) {
case 0:
	Value = 0;
	break;
case 1:
	Value = ST7789_MADCTL_MX;
	break;
case 2:
	Value = ST7789_MADCTL_MY;
	break;
case 3:
	Value = ST7789_MADCTL_MX | ST7789_MADCTL_MY;
	break;
case 4:
	Value = ST7789_MADCTL_MV;
	break;
case 5:
	Value = ST7789_MADCTL_MV | ST7789_MADCTL_MX;
	break;
case 6:
	Value = ST7789_MADCTL_MV | ST7789_MADCTL_MY;
	break;
case 7:
	Value = ST7789_MADCTL_MV | ST7789_MADCTL_MX | ST7789_MADCTL_MY;
	break;
}

if (VertMirror)
	Value = ST7789_MADCTL_ML;
if (HorizMirror)
	Value = ST7789_MADCTL_MH;

if (IsBGR)
	Value |= ST7789_MADCTL_BGR;

vFinaLCD_SendData(Value);
}

void vFinaLCD_DisplayPower(uint8_t On) {
if (On)
	vFinaLCD_SendCmd(ST7789_Cmd_DISPON);
else
	vFinaLCD_SendCmd(ST7789_Cmd_DISPOFF);
}

void vFinaLCD_InversionMode(uint8_t Mode) {
if (Mode)
	vFinaLCD_SendCmd(ST7789_Cmd_INVON);
else
	vFinaLCD_SendCmd(ST7789_Cmd_INVOFF);
}

void vFinaLCD_DrawBMP(uint16_t x, uint16_t y, const uint8_t *pArr) {
uint8_t *pBmp;
uint8_t *start;
uint8_t *end;
uint32_t offset = 0, size = 0;
int32_t height = 0, width = 0;
uint16_t colordepth = 0;
uint32_t color = 0;

pBmp = (uint8_t*) pArr;
/* Read bitmap size */
size = *(volatile uint16_t*) (pBmp + 2);
size |= (*(volatile uint16_t*) (pBmp + 4)) << 16;
/* Get bitmap data address offset */
offset = *(volatile uint16_t*) (pBmp + 10);
offset |= (*(volatile uint16_t*) (pBmp + 12)) << 16;
/* Read bitmap width */
width = *(uint16_t*) (pBmp + 18);
width |= (*(uint16_t*) (pBmp + 20)) << 16;
/* Read bitmap height */
height = *(uint16_t*) (pBmp + 22);
height |= (*(uint16_t*) (pBmp + 24)) << 16;
/* Read color depth */
colordepth = *(uint16_t*) (pBmp + 28);

start = (uint8_t*) pBmp + offset;
end = (uint8_t*) pBmp + size;

vFinaLCD_SetWindow(x, y, x + width - 1, y + abs(height) - 1);
HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET);
if (colordepth == 16) { //*16 біт bmp*//
	if (height < 0) {
		pBmp = start;
		while (pBmp < end) {
			vFinaLCD_WriteMultiple(pBmp, 2);
			pBmp += 2;
		}
	} else {
		pBmp = end - 1;
		while (pBmp >= start) {
			vFinaLCD_WriteMultiple(pBmp - 1, 2);
			pBmp -= 2;
		}
	}
} else if (colordepth == 24) {  //*24 біт bmp*//
	if (height < 0) {
		pBmp = start;
		while (pBmp < end) {
			color = vFinaLCD_Color666(*(pBmp), *(pBmp + 1), *(pBmp + 2));
			vFinaLCD_WriteMultiple((uint8_t*) &color, 2);
			pBmp += 3;
		}
	} else {
		pBmp = end - 1;
		while (pBmp >= start) {

			color = vFinaLCD_Color666(*(pBmp), *(pBmp + 1), *(pBmp - 2));
			vFinaLCD_WriteMultiple((uint8_t*) &color, 2);
			pBmp -= 3;
		}
	}
}
vFinaLCD_SetWindow(0, 0, width - 1, height - 1);
}

void vFinaLCD_WriteMultiple(uint8_t *pData, uint32_t size) {
if (size == 1) {
	/* Для відправки одного байку використовуй стандартний SPI */
	/* Відправка */
	//LCD_Write(*pData);
} else {

	/* Використовується прямий доступ до SPI для оптимізації */
	for (uint32_t counter = size; counter != 0; counter -= 2) {
		while (((SPI1->SR) & SPI_FLAG_TXE) != SPI_FLAG_TXE) {
		}
		/* Need to invert bytes for LCD*/
		*((__IO uint8_t*) &(SPI1->DR)) = *(pData + 1);
		while (((SPI1->SR) & SPI_FLAG_TXE) != SPI_FLAG_TXE) {
		}
		*((__IO uint8_t*) &(SPI1->DR)) = *pData;
		pData += 2;
	}

	/* Wait until the bus is ready before releasing Chip select */
	while (((SPI1->SR) & SPI_FLAG_BSY) != RESET) {
	}
}
}

void vFinaLCD_DrawPixel(int16_t x, int16_t y, uint32_t color) {
if ((x < 0) || (x >= ST7789_Width) || (y < 0) || (y >= ST7789_Height))
	return;

vFinaLCD_SetWindow(x, y, x, y);
vFinaLCD_RamWrite(&color, 3);
}

uint32_t vFinaLCD_Color565(uint8_t r, uint8_t g, uint8_t b) {

return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);

}

uint32_t vFinaLCD_Color666(uint8_t r, uint8_t g, uint8_t b) {

return ((r & 0xFC) << 10) | ((g & 0xFC) << 4) | ((b & 0xFC) >> 2);

}

inline uint32_t color16to24(uint16_t color565) {

uint8_t r = (color565 >> 8) & 0xF8;
r |= (r >> 5);
uint8_t g = (color565 >> 3) & 0xFC;
g |= (g >> 6);
uint8_t b = (color565 << 3) & 0xF8;
b |= (b >> 5);

return ((uint32_t) r << 16) | ((uint32_t) g << 8) | ((uint32_t) b << 0);
}

uint16_t alphaBlend(uint8_t alpha, uint16_t fgc, uint16_t bgc) {
// For speed use fixed point maths and rounding to permit a power of 2 division
uint16_t fgR = ((fgc >> 10) & 0x3E) + 1;
uint16_t fgG = ((fgc >> 4) & 0x7E) + 1;
uint16_t fgB = ((fgc << 1) & 0x3E) + 1;

uint16_t bgR = ((bgc >> 10) & 0x3E) + 1;
uint16_t bgG = ((bgc >> 4) & 0x7E) + 1;
uint16_t bgB = ((bgc << 1) & 0x3E) + 1;

// Shift right 1 to drop rounding bit and shift right 8 to divide by 256
uint16_t r = (((fgR * alpha) + (bgR * (255 - alpha))) >> 9);
uint16_t g = (((fgG * alpha) + (bgG * (255 - alpha))) >> 9);
uint16_t b = (((fgB * alpha) + (bgB * (255 - alpha))) >> 9);

// Combine RGB565 colours into 16 bits
//return ((r&0x18) << 11) | ((g&0x30) << 5) | ((b&0x18) << 0); // 2 bit greyscale
///return ((r&0x1E) << 11) | ((g&0x3C) << 5) | ((b&0x1E) << 0); // 4 bit greyscale
return (r << 11) | (g << 5) | (b << 0);
}

uint32_t alphaBlend24(uint8_t alpha, uint32_t fgc, uint32_t bgc, uint8_t dither) {

if (dither) {
	int16_t alphaDither = (int16_t) alpha - dither + random(2 * dither + 1); // +/-dither randomised
	alpha = (uint8_t) alphaDither;
	if (alphaDither < 0)
		alpha = 0;
	if (alphaDither > 255)
		alpha = 255;
}

// For speed use fixed point maths and rounding to permit a power of 2 division
uint16_t fgR = ((fgc >> 15) & 0x1FE) + 1;
uint16_t fgG = ((fgc >> 7) & 0x1FE) + 1;
uint16_t fgB = ((fgc << 1) & 0x1FE) + 1;

uint16_t bgR = ((bgc >> 15) & 0x1FE) + 1;
uint16_t bgG = ((bgc >> 7) & 0x1FE) + 1;
uint16_t bgB = ((bgc << 1) & 0x1FE) + 1;

// Shift right 1 to drop rounding bit and shift right 8 to divide by 256
uint16_t r = (((fgR * alpha) + (bgR * (255 - alpha))) >> 9);
uint16_t g = (((fgG * alpha) + (bgG * (255 - alpha))) >> 9);
uint16_t b = (((fgB * alpha) + (bgB * (255 - alpha))) >> 9);

// Combine RGB colours into 24 bits
return (r << 16) | (g << 8) | (b << 0);
}

void vFinaLCD_print_7x11(uint16_t x, uint16_t y, uint16_t TextColor,
	uint16_t BgColor, uint8_t TransparentBg, char *str) {
unsigned char type = *str;
if (type >= 128)
	x = x - 3;
while (*str) {
	vFinaLCD_DrawChar_7x11(x, y, TextColor, BgColor, TransparentBg, *str++);
	unsigned char type = *str;
	if (type >= 128)
		x = x + 8;
	else
		x = x + 8;
}
}

void vFinaLCD_DrawChar_7x11(uint16_t x, uint16_t y, uint16_t TextColor,
	uint16_t BgColor, uint8_t TransparentBg, unsigned char c) {
uint8_t i, j;
uint8_t buffer[11];

if ((x >= 240) || (y >= 240) || ((x + 4) < 0) || ((y + 7) < 0))
	return;

// Copy selected simbol to buffer
memcpy(buffer, &font7x11[(c - 32) * 11], 11);
for (j = 0; j < 11; j++) {
	for (i = 0; i < 7; i++) {
		if ((buffer[j] & (1 << i)) == 0) {
			if (!TransparentBg)
				ST7789_DrawPixel(x + i, y + j, BgColor);
		} else
			ST7789_DrawPixel(x + i, y + j, TextColor);
	}
}
}

uint16_t alphaBlendwD(uint8_t alpha, uint16_t fgc, uint16_t bgc, uint8_t dither) {
if (dither) {
	int16_t alphaDither = (int16_t) alpha - dither + random(2 * dither + 1); // +/-4 randomised
	alpha = (uint8_t) alphaDither;
	if (alphaDither < 0)
		alpha = 0;
	if (alphaDither > 255)
		alpha = 255;
}

return alphaBlend(alpha, fgc, bgc);
}

void vFinaLCD_DrawBitmapArray(const uint32_t *pData) {
uint8_t LCD_HEIGHT = 239; // ширина
uint8_t LCD_WIDTH = 239;  // довжина
uint32_t data = 0;

for (uint8_t j = 0; j <= LCD_HEIGHT; j++) {
	for (uint8_t i = 0; i <= LCD_WIDTH; i++) {
		vFinaLCD_DrawPixel(i, j, pData[data++]);
	}
}

}
