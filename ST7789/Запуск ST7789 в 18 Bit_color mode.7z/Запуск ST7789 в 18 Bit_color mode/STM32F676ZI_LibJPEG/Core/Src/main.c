/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "Fina_st7789.h"
#include "stdarg.h"
#include "tjpgd.h"
#include "stdlib.h"
#include "i2lcd_restretto.h"
#include "ristretto_24bit.h"
#include "bitmap_data.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define LCD_Width 240
#define LCD_Height 240

#if (JPEG_RGB_FORMAT == JPEG_ARGB8888)
#define BYTES_PER_PIXEL 4  /* Number of bytes in a pixel */
#elif (JPEG_RGB_FORMAT == JPEG_RGB888)
  #define BYTES_PER_PIXEL 3  /* Number of bytes in a pixel */
#elif (JPEG_RGB_FORMAT == JPEG_RGB565)
#define BYTES_PER_PIXEL 2  /* Number of bytes in a pixel */
#else
  #error "unknown JPEG_RGB_FORMAT "
#endif /* JPEG_RGB_FORMAT */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
typedef struct {
	const BYTE *jpic;
	WORD jsize;
	WORD joffset;
} IODEV;

uint32_t JpegProcessing_End = 0;
uint16_t alpha = 0;
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

DMA2D_HandleTypeDef hdma2d;

JPEG_HandleTypeDef hjpeg;

SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi5;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
void ResultParser(FRESULT OperationResult);
void UART_Printf(const char *fmt, ...);
int DisplayImageFromSDcard(const char *fname);
void DisplayJPEG_FromSD(const char *fname);
void DisplayHardwareMethodJPEG(const char *fname);
void OnError_Handler(void);

/*Callback-функції, що викликаються у недрах LibJPEG*/
UINT input_func(JDEC *jd, BYTE *buff, UINT ndata) {
	IODEV *dev = (IODEV*) jd->device;

	ndata = dev->jsize - dev->joffset > ndata ?
			ndata : dev->jsize - dev->joffset;

	if (buff)
		memcpy(buff, dev->jpic + dev->joffset, ndata);

	dev->joffset += ndata;

	return ndata;
}
UINT output_func(JDEC *jd, void *bitmap, JRECT *rect) {

	WORD *bmp = (WORD*) bitmap;

	WORD x;
	WORD y;

	WORD i = 0;

	for (y = rect->top; y <= rect->bottom; y++) {
		for (x = rect->left; x <= rect->right; x++) {

			vFinaLCD_DrawPixel(x, y, alphaBlend(21, 65535, bmp[i++]));

		}
	}

	return 1;	// Continue to decompress
}

#define SCALE	0	/* Output scaling 0:1/1, 1:1/2, 2:1/4 or 3:1/8 */
BYTE jdwork[3100];
BYTE LCD_BUFFER[0x00005ff0]; /* В цей массив FAT-FS запише побайтно дані з JPEG-файлу на MicroSD */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI5_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_DMA2D_Init(void);
static void MX_JPEG_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	/* USER CODE BEGIN 1 */
	uint32_t xPos = 0, yPos = 0;
	uint32_t width_offset = 0;
	/* USER CODE END 1 */

	/* Enable I-Cache---------------------------------------------------------*/
	SCB_EnableICache();

	/* Enable D-Cache---------------------------------------------------------*/
	SCB_EnableDCache();

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_SPI1_Init();
	MX_FATFS_Init();
	MX_SPI5_Init();
	MX_USART3_UART_Init();
	MX_DMA2D_Init();
	MX_JPEG_Init();
	/* USER CODE BEGIN 2 */

	vFinaLCD_Init();

	//DisplayJPEG_FromSD("final.jpg"); /*Вивід jpeg*/

	/*Розбивка 24 Біт RGB на компоненти*/

	/*
	uint32_t RGB_COLOR = 0x4567AA;
	UART_Printf("RGB COLOR: 0x%X\n", RGB_COLOR);

	uint8_t R_COMPONENT = 0;
	uint8_t G_COMPONENT = 0;
	uint8_t B_COMPONENT = 0;

	R_COMPONENT = RGB_COLOR >> 16; // LSB
	UART_Printf("R_COMPONENT: 0x%X\n", R_COMPONENT);

	G_COMPONENT = RGB_COLOR >> 8;
	UART_Printf("G_COMPONENT: 0x%X\n", G_COMPONENT);

	B_COMPONENT = RGB_COLOR & 0xFF; // MSB
	UART_Printf("B_COMPONENT: 0x%X\n", B_COMPONENT);
	/*Кінець Розбивки 32 Біт RGB на компоненти*/

	//Формування з 6 Біт кольору, 18 бітного значення кольору пікселя/
	/*
	UART_Printf("----------------------------------------\r\n");

	uint8_t R = 0xF0;
	uint8_t G = 0xF0;
	uint8_t B = 0xF0;

	UART_Printf("(6 Bit)R: 0x%X\n", R);
	UART_Printf("(6 Bit)G: 0x%X\n", G);
	UART_Printf("(6 Bit)B: 0x%X\n", B);

	uint32_t RESULT = 0;

	/* Конвертуємо 24 біта у 18 Біт RGB 666 */

	//0x27CCC  0d163020  0b‭00100111110011001100
	//R &= 0xFC;
	//G &= 0xFC;
	//B &= 0xFC;
	//RESULT = ((R & 0xFC) << 10) | ((G & 0xFC) << 4) | ((B & 0xFC) >> 2);

	/*  D7....D0 D7....D0 D7....D0
	 *  ######## ######## ########
	 *  RRRRRR## ######## ########
	 *  ######## GGGGGG## ########
	 *  ######## ######## BBBBBB##
	 *  RRRRRR## GGGGGG## BBBBBB##
	 */

	//UART_Printf("(18 Bit HEX) RESULT: 0x%X\n", RESULT);
	//UART_Printf("(18 Bit DEC) RESULT: %d\n", RESULT);

	//ST7789_DrawBMP(0, 0,image_data_ristrettov3);

	vFinaLCD_FillScreen(YELLOW);


	vFinaLCD_DrawBitmapArray(bitmap);

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {

	}

	/* USER CODE END WHILE */

	/* USER CODE BEGIN 3 */

	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
	/** Initializes the CPU, AHB and APB busses clocks
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 8;
	RCC_OscInitStruct.PLL.PLLN = 216;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}
	/** Activate the Over-Drive mode
	 */
	if (HAL_PWREx_EnableOverDrive() != HAL_OK) {
		Error_Handler();
	}
	/** Initializes the CPU, AHB and APB busses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK) {
		Error_Handler();
	}
	PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USART3;
	PeriphClkInitStruct.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief DMA2D Initialization Function
 * @param None
 * @retval None
 */
static void MX_DMA2D_Init(void) {

	/* USER CODE BEGIN DMA2D_Init 0 */

	/* USER CODE END DMA2D_Init 0 */

	/* USER CODE BEGIN DMA2D_Init 1 */

	/* USER CODE END DMA2D_Init 1 */
	hdma2d.Instance = DMA2D;
	hdma2d.Init.Mode = DMA2D_M2M;
	hdma2d.Init.ColorMode = DMA2D_OUTPUT_RGB565;
	hdma2d.Init.OutputOffset = 0;
	hdma2d.LayerCfg[1].InputOffset = 0;
	hdma2d.LayerCfg[1].InputColorMode = DMA2D_INPUT_RGB565;
	hdma2d.LayerCfg[1].AlphaMode = DMA2D_NO_MODIF_ALPHA;
	hdma2d.LayerCfg[1].InputAlpha = 0;
	hdma2d.LayerCfg[1].AlphaInverted = DMA2D_REGULAR_ALPHA;
	hdma2d.LayerCfg[1].RedBlueSwap = DMA2D_RB_REGULAR;
	if (HAL_DMA2D_Init(&hdma2d) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_DMA2D_ConfigLayer(&hdma2d, 1) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN DMA2D_Init 2 */

	/* USER CODE END DMA2D_Init 2 */

}

/**
 * @brief JPEG Initialization Function
 * @param None
 * @retval None
 */
static void MX_JPEG_Init(void) {

	/* USER CODE BEGIN JPEG_Init 0 */

	/* USER CODE END JPEG_Init 0 */

	/* USER CODE BEGIN JPEG_Init 1 */

	/* USER CODE END JPEG_Init 1 */
	hjpeg.Instance = JPEG;
	if (HAL_JPEG_Init(&hjpeg) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN JPEG_Init 2 */

	/* USER CODE END JPEG_Init 2 */

}

/**
 * @brief SPI1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_SPI1_Init(void) {

	/* USER CODE BEGIN SPI1_Init 0 */

	/* USER CODE END SPI1_Init 0 */

	/* USER CODE BEGIN SPI1_Init 1 */

	/* USER CODE END SPI1_Init 1 */
	/* SPI1 parameter configuration*/
	hspi1.Instance = SPI1;
	hspi1.Init.Mode = SPI_MODE_MASTER;
	hspi1.Init.Direction = SPI_DIRECTION_2LINES;
	hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
	hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;
	hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
	hspi1.Init.NSS = SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
	hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi1.Init.CRCPolynomial = 7;
	hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
	hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
	if (HAL_SPI_Init(&hspi1) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN SPI1_Init 2 */

	/* USER CODE END SPI1_Init 2 */

}

/**
 * @brief SPI5 Initialization Function
 * @param None
 * @retval None
 */
static void MX_SPI5_Init(void) {

	/* USER CODE BEGIN SPI5_Init 0 */

	/* USER CODE END SPI5_Init 0 */

	/* USER CODE BEGIN SPI5_Init 1 */

	/* USER CODE END SPI5_Init 1 */
	/* SPI5 parameter configuration*/
	hspi5.Instance = SPI5;
	hspi5.Init.Mode = SPI_MODE_MASTER;
	hspi5.Init.Direction = SPI_DIRECTION_2LINES;
	hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
	hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
	hspi5.Init.CLKPhase = SPI_PHASE_1EDGE;
	hspi5.Init.NSS = SPI_NSS_SOFT;
	hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
	hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi5.Init.CRCPolynomial = 7;
	hspi5.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
	hspi5.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
	if (HAL_SPI_Init(&hspi5) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN SPI5_Init 2 */

	/* USER CODE END SPI5_Init 2 */

}

/**
 * @brief USART3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART3_UART_Init(void) {

	/* USER CODE BEGIN USART3_Init 0 */

	/* USER CODE END USART3_Init 0 */

	/* USER CODE BEGIN USART3_Init 1 */

	/* USER CODE END USART3_Init 1 */
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 115200;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart3) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USART3_Init 2 */

	/* USER CODE END USART3_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOC, CS_SD_CARD_Pin | GPIO_PIN_4, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1 | GPIO_PIN_12 | GPIO_PIN_9,
			GPIO_PIN_RESET);

	/*Configure GPIO pins : CS_SD_CARD_Pin PC4 */
	GPIO_InitStruct.Pin = CS_SD_CARD_Pin | GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pin : PA4 */
	GPIO_InitStruct.Pin = GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : PB1 PB12 PB9 */
	GPIO_InitStruct.Pin = GPIO_PIN_1 | GPIO_PIN_12 | GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void DisplayJPEG_FromSD(const char *fname) {

	/*Початок монтування файлової системи*/

	FATFS fs;
	FRESULT res = f_mount(&fs, "", 0);
	if (res != FR_OK) {
		UART_Printf("f_mount() failed, res = %d\r\n", res);
	}
	UART_Printf("f_mount() done!\r\n");
	/*Кінець монтування файлової системи*/

	/*Починаю відкривати файл у файловій системі FAT*/
	UART_Printf("Openning %s...\r\n", fname);
	FIL file;
	res = f_open(&file, fname, FA_READ);
	ResultParser(res);
	if (res != FR_OK) {
		UART_Printf("f_open() failed, res = %d\r\n", res);

	}
	UART_Printf("File opened, reading...\r\n");
	/* Закінчую відкривати файл у файловій системі FAT */

	/*Початок зчитування файлу */
	unsigned int bytesRead;
	res = f_read(&file, LCD_BUFFER, sizeof(LCD_BUFFER), &bytesRead);
	ResultParser(res);
	/*Закриття сесії читання файлу*/
	UART_Printf("closing file %s\r\n", fname);
	res = f_close(&file);
	ResultParser(res);

	/* Початок декодування отриманих даних JPEG з SD-картки в BITMAP */
	JDEC jd;		// TJDEC decompression object
	IODEV iodev;// Identifier of the decompression session (depends on application)
	JRESULT rc;		// Result

	iodev.jpic = LCD_BUFFER;
	iodev.jsize = sizeof(LCD_BUFFER);
	iodev.joffset = 0;

	rc = jd_prepare(&jd, input_func, jdwork, sizeof(jdwork), &iodev);
	if (rc) {
		vFinaLCD_FillScreen(0xFFFFFF);
		for (;;)
			;
	}

	rc = jd_decomp(&jd, output_func, SCALE);
	if (rc) {
		vFinaLCD_FillScreen(0xFFFFFF);
		for (;;)
			;
	}
	/* Кінець декодування отриманих даних JPEG з SD-картки в BITMAP */

}

void DisplayHardwareMethodJPEG(const char *fname) {
	/*Початок монтування файлової системи*/
	FIL MyJPEG_File;
	FATFS fs;
	FRESULT res = f_mount(&fs, "", 0);
	if (res != FR_OK) {
		UART_Printf("f_mount() failed, res = %d\r\n", res);
	}
	UART_Printf("f_mount() done!\r\n");
	/*Кінець монтування файлової системи*/

	/*Починаю відкривати файл у файловій системі FAT*/
	UART_Printf("Openning %s...\r\n", fname);
	res = f_open(&MyJPEG_File, fname, FA_READ);
	ResultParser(res);
	if (res != FR_OK) {
		UART_Printf("f_open() failed, res = %d\r\n", res);
	}
	UART_Printf("File %s opened, reading...\r\n", fname);
	/* Закінчую відкривати файл у файловій системі FAT */
	JPEG_Decode_DMA(&hjpeg, &MyJPEG_File, JPEG_OUTPUT_DATA_BUFFER);
	/* Очікую завершення декодування */
	do {
		JPEG_InputHandler(&hjpeg);

	} while (JpegProcessing_End == 0);

}

int DisplayImageFromSDcard(const char *fname) {

	UART_Printf("Openning %s...\r\n", fname);
	FIL file;
	FRESULT res = f_open(&file, fname, FA_READ);
	ResultParser(res);
	if (res != FR_OK) {
		UART_Printf("f_open() failed, res = %d\r\n", res);
		return -1;
	}
	UART_Printf("File opened, reading...\r\n");

	unsigned int bytesRead;
	uint8_t header[34];
	res = f_read(&file, header, sizeof(header), &bytesRead);

	if (res != FR_OK) {
		UART_Printf("f_read() failed, res = %d\r\n", res);
		f_close(&file);
		return -2;
	}

	if ((header[0] != 0x42) || (header[1] != 0x4D)) {
		UART_Printf("Wrong BMP signature: 0x%02X 0x%02X\r\n", header[0],
				header[1]);
		f_close(&file);
		return -3;
	}

	uint32_t imageOffset = header[10] | (header[11] << 8) | (header[12] << 16)
			| (header[13] << 24);
	uint32_t imageWidth = header[18] | (header[19] << 8) | (header[20] << 16)
			| (header[21] << 24);
	uint32_t imageHeight = header[22] | (header[23] << 8) | (header[24] << 16)
			| (header[25] << 24);
	uint16_t imagePlanes = header[26] | (header[27] << 8);
	uint16_t imageBitsPerPixel = header[28] | (header[29] << 8);
	uint32_t imageCompression = header[30] | (header[31] << 8)
			| (header[32] << 16) | (header[33] << 24);

	UART_Printf("--- Image info ---\r\n"
			"Pixels offset: %lu\r\n"
			"WxH: %lux%lu\r\n"
			"Planes: %d\r\n"
			"Bits per pixel: %d\r\n"
			"Compression: %d\r\n"
			"------------------\r\n", imageOffset, imageWidth, imageHeight,
			imagePlanes, imageBitsPerPixel, imageCompression);

	if ((imageWidth != 240) || (imageHeight != 240)) {
		UART_Printf("Wrong BMP size, %dx%d expected\r\n", 240, 240);
		f_close(&file);
		return -4;
	}

	if ((imagePlanes != 1) || (imageBitsPerPixel != 24)
			|| (imageCompression != 0)) {
		UART_Printf("Unsupported image format\r\n");
		f_close(&file);
		return -5;
	}

	res = f_lseek(&file, imageOffset);
	if (res != FR_OK) {
		UART_Printf("f_lseek() failed, res = %d\r\n", res);
		f_close(&file);
		return -6;
	}

// row size is aligned to 4 bytes
	uint8_t imageRow[(240 * 3 + 3) & ~3];
	for (uint32_t y = 0; y < imageHeight; y++) {
		uint32_t rowIdx = 0;
		res = f_read(&file, imageRow, sizeof(imageRow), &bytesRead);
		if (res != FR_OK) {
			UART_Printf("f_read() failed, res = %d\r\n", res);
			f_close(&file);
			return -7;

		}

		for (uint32_t x = 0; x < imageWidth; x++) {
			uint8_t b = imageRow[rowIdx++];
			uint8_t g = imageRow[rowIdx++];
			uint8_t r = imageRow[rowIdx++];
			uint16_t color565 = LCD_Color565(r, g, b);
			vFinaLCD_DrawPixel(x, imageHeight - y - 1, color565);
		}
	}

	res = f_close(&file);
	if (res != FR_OK) {
		UART_Printf("f_close() failed, res = %d\r\n", res);
		return -8;
	}

	return 0;
}

void UART_Printf(const char *fmt, ...) {
	char buff[512];
	va_list args;
	va_start(args, fmt);
	vsnprintf(buff, sizeof(buff), fmt, args);
	HAL_UART_Transmit(&huart3, (uint8_t*) buff, strlen(buff),
	HAL_MAX_DELAY);
	va_end(args);
}

void ResultParser(FRESULT OperationResult) {

	switch (OperationResult) {
	case 0:

		UART_Printf("Result Parser: (0) Succeeded \r\n");

		break;
	case 1:
		UART_Printf(
				"Result Parser: (1) A hard error occurred in the low level disk I/O layer \r\n");
		break;
	case 2:
		UART_Printf("Result Parser: (2) Assertion failed \r\n");
		break;
	case 3:
		UART_Printf("Result Parser: (3) The physical drive cannot work \r\n");
		break;
	case 4:
		UART_Printf("Result Parser: (4) Could not find the file \r\n");
		break;
	case 5:
		UART_Printf("Result Parser: (5) Could not find the path \r\n");
		break;
	case 6:
		UART_Printf("Result Parser: (6) The path name format is invalid \r\n");
		break;
	case 7:
		UART_Printf(
				"Result Parser: (7) Access denied due to prohibited access or directory full \r\n");
		break;
	case 8:
		UART_Printf(
				"Result Parser: (8) Access denied due to prohibited access \r\n");
		break;
	case 9:
		UART_Printf(
				"Result Parser: (9) The file/directory object is invalid \r\n");
		break;
	case 10:
		UART_Printf(
				"Result Parser: (10) The physical drive is write protected a\r\n");
		break;
	case 11:
		UART_Printf(
				"Result Parser: (11) The logical drive number is invalid \r\n");
		break;
	case 12:
		UART_Printf("Result Parser: (12) The volume has no work area \r\n");
		break;
	case 13:
		UART_Printf("Result Parser: (13) There is no valid FAT volume \r\n");
		break;
	case 14:
		UART_Printf(
				"Result Parser: (14) The f_mkfs() aborted due to any parameter error \r\n");
		break;
	case 15:
		UART_Printf(
				"Result Parser: (15) Could not get a grant to access the volume within defined period \r\n");
		break;
	case 16:
		UART_Printf(
				"Result Parser: (16) The operation is rejected according to the file sharing policy \r\n");
		break;
	case 17:
		UART_Printf(
				"Result Parser: (17) LFN working buffer could not be allocated \r\n");
		break;
	case 18:
		UART_Printf("Result Parser: (18) Number of open files \r\n");
		break;
	case 19:
		UART_Printf("Result Parser: (19) Given parameter is invalid \r\n");
		break;
	default:
		break;
	}

}
void OnError_Handler(void) {

	while (1) {
		;
	} /* Blocking on error */
}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */

	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
